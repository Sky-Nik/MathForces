#!/usr/bin/env python
import json


def p_tex2html(p_id):
    p_tex = open(f'p_{p_id}.tex', 'r', encoding='utf-8').read()
    k, p_html = 0, ''
    for c in p_tex:
        if c == '$':
            k += 1
            if k & 1:
                p_html += '\\('
            else:
                p_html += '\\)'
        elif c == '\\':
            p_html += c
        else:
            p_html += c
    p_html = p_html.replace('---', '&mdash;')
    return p_html


def p_json2html(p_id):
    p = json.loads(open(f'p_{p_id}.json', 'r', encoding='utf-8').read())
    # assert p_id == p['id']
    open(f'p_{p_id}.html', 'w', encoding='utf-8').write(f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Задача №{p['id']}: {p['name']}</title>
            <meta charset="utf-8">
            <script type="text/javascript" async
            src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-MML-AM_CHTML" async>
            </script>
        </head>
        <body>
            <h1>Задача №{p['id']}: {p['name']}</h1>
            <p>{p_tex2html(p_id)}</p>
        </body>
        </html>
    ''')


def ps2c_html(p_ids, c_id):
    c_html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Сорвевнование №{c_id}</title>
            <meta charset="utf-8">
            <script type="text/javascript" async
            src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-MML-AM_CHTML" async>
            </script>
        </head>
        <body>'''

    for p_id in p_ids:
        p = json.loads(open(f'p_{p_id}.json', 'r', encoding='utf-8').read())
        c_html += f'''
            <h1>Задача №{p['id']}: {p['name']}</h1>
            <p>{p_tex2html(p_id)}</p>
        '''

    c_html += '</body>\n\t\t</html>'
    open(f'c_{c_id}.html', 'w', encoding='utf-8').write(c_html)


def ps2c_tex(p_ids, c_id):
    c_tex = '\\input{c.sty}\n\n\\begin{document}\n\n\\title{Сорвевнование №' + f'{c_id}' + '}\n\\maketitle\n\n'

    for p_id in p_ids:
        p = json.loads(open(f'p_{p_id}.json', 'r', encoding='utf-8').read())
        c_tex += '\\begin{problem}' + f"[{p['name']}]" + '\n\t' + open(f'p_{p_id}.tex', 'r', encoding='utf-8').read()+ '\n\\end{problem}\n\n'

    c_tex += '\\end{document}'
    open(f'c_{c_id}.tex', 'w', encoding='utf-8').write(c_tex)


if __name__ == "__main__":
    for p_id in [1, 2, 3, 4, 5]:
        p_json2html(p_id)
    ps2c_html([1, 2, 3, 4, 5], 1)
    ps2c_tex([1, 2, 3, 4, 5], 1)
